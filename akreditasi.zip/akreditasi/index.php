<?php
// Redirect otomatis ke halaman login
header("Location: login.php");
exit();
?>
